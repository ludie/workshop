# by LCCL Coding Academy, www.LccLcoding.com
# for Shopee Code League 2020

s = input('String: ')
print(f'Unique chars:{len(set(s))}')